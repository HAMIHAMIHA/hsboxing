/** @type {import("@wxcloud/core").CloudConfig} */
const cloudConfig = {
  server: {},
  type: "run"
}

module.exports = cloudConfig
